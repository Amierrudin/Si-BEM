<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * CMS Sekolahku | CMS (Content Management System) dan PPDB/PMB Online GRATIS
 * untuk sekolah SD/Sederajat, SMP/Sederajat, SMA/Sederajat, dan Perguruan Tinggi
 * @version    2.3.0
 * @author     Anton Sofyan | https://facebook.com/antonsofyan | 4ntonsofyan@gmail.com | 0857 5988 8922
 * @copyright  (c) 2014-2019
 * @link       http://sekolahku.web.id
 *
 * PERINGATAN :
 * 1. TIDAK DIPERKENANKAN MEMPERJUALBELIKAN APLIKASI INI TANPA SEIZIN DARI PIHAK PENGEMBANG APLIKASI.
 * 2. TIDAK DIPERKENANKAN MENGHAPUS KODE SUMBER APLIKASI.
 * 3. TIDAK MENYERTAKAN LINK KOMERSIL (JASA LAYANAN HOSTING DAN DOMAIN) YANG MENGUNTUNGKAN SEPIHAK.
 */

class Gallery_photos extends Public_Controller {

	/**
	 * Total Rows
	 */
	private $total_rows = 0;

	/**
	 * Total Page
	 */
	private $total_pages = 0;

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
		$this->load->model('public/m_albums');
		$this->total_rows = $this->m_albums->total_rows();
		$this->total_pages = ceil($this->total_rows / 6);
	}

	/**
	 * Index
	 */
	public function index() {
		$this->vars['total_pages'] = $this->total_pages;
		$this->vars['query'] = $this->m_albums->get_albums( 6 );
		$this->vars['content'] = 'themes/'.theme_folder().'/loop-albums';
		$this->load->view('themes/'.theme_folder().'/index', $this->vars);
	}

	/**
	 * More Photos
	 */
	public function more_photos() {
		if ($this->input->is_ajax_request()) {
			$page_number = (int) $this->input->post('page_number', true);
			$offset = ($page_number - 1) * 6;
			$query = $this->m_albums->get_albums(6, $offset);
			$this->vars = [
				'rows' => $query->result(),
				'total_rows' => $this->total_rows
			];

			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
	 * List Images
	 * @return Object
	 */
	public function preview() {
		if ($this->input->is_ajax_request()) {
			$id = $this->input->post('id');
			if (_isInteger( $id )) {
				$this->load->model('m_photos');
				$query = $this->m_photos->get_photos($id);
				$items = [];
				foreach($query->result() as $row) {
					$items[] = [
						'src' => base_url('media_library/albums/large/'.$row->photo_name)
					];
				}
				$this->vars = [
					'count' => count($items),
					'items' => $items
				];
			}

			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}
}
