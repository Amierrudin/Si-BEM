<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * CMS Sekolahku | CMS (Content Management System) dan PPDB/PMB Online GRATIS
 * untuk sekolah SD/Sederajat, SMP/Sederajat, SMA/Sederajat, dan Perguruan Tinggi
 * @version    2.3.0
 * @author     Anton Sofyan | https://facebook.com/antonsofyan | 4ntonsofyan@gmail.com | 0857 5988 8922
 * @copyright  (c) 2014-2019
 * @link       http://sekolahku.web.id
 *
 * PERINGATAN :
 * 1. TIDAK DIPERKENANKAN MEMPERJUALBELIKAN APLIKASI INI TANPA SEIZIN DARI PIHAK PENGEMBANG APLIKASI.
 * 2. TIDAK DIPERKENANKAN MENGHAPUS KODE SUMBER APLIKASI.
 * 3. TIDAK MENYERTAKAN LINK KOMERSIL (JASA LAYANAN HOSTING DAN DOMAIN) YANG MENGUNTUNGKAN SEPIHAK.
 */

class Print_admission_form extends Public_Controller {

	/**
	* Constructor
	* @access  public
	*/
	public function __construct() {
		parent::__construct();
	}

	/**
	* Index
	* @access  public
	*/
	public function index() {
		$this->load->model('m_settings');
		$recaptcha = $this->m_settings->get_recaptcha();
		$this->vars['recaptcha_site_key'] = $recaptcha['recaptcha_site_key'];
		$this->vars['page_title'] = 'Cetak Formulir Penerimaan '. ($this->session->school_level >= 5 ? 'Mahasiswa' : 'Peserta Didik').' Baru Tahun '.$this->session->admission_year;
		$this->vars['action'] = 'print_admission_form/process';
		$this->vars['button'] = '<i class="fa fa-file-pdf-o"></i> CETAK FORMULIR';
		$this->vars['onclick'] = 'print_admission_form()';
		$this->vars['content'] = 'themes/'.theme_folder().'/admission-search-form';
		$this->load->view('themes/'.theme_folder().'/index', $this->vars);
	}

	/**
	* PDF Generated Process
	* @access  public
	*/
	public function process() {
		if ($this->input->is_ajax_request()) {
			$recaptcha_status = $this->session->recaptcha_status;
			if (NULL !== $recaptcha_status && $recaptcha_status == 'enable') {
				$this->load->library('recaptcha');
				$recaptcha = $this->input->post('recaptcha');
				$recaptcha_verified = $this->recaptcha->verifyResponse($recaptcha);
				if (!$recaptcha_verified['success']) {
					$this->vars['status'] = 'recaptcha_error';
					$this->vars['message'] = 'Recaptcha Error!';
					$this->output
						->set_content_type('application/json', 'utf-8')
						->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
						->_display();
					exit;
				}
			}

			if ($this->validation()) {
				$birth_date = $this->input->post('birth_date');
				$registration_number = $this->input->post('registration_number');
				if (is_valid_date($birth_date) && strlen($registration_number) == 10 && ctype_digit((string) $registration_number)) {
					$this->load->model('m_registrants');
					$result = $this->m_registrants->find_registrant($birth_date, $registration_number);
					if (!count($result)) {
						$this->vars['status'] = 'warning';
						$this->vars['message'] = 'Data dengan tanggal lahir '.indo_date($birth_date).' dan nomor pendaftaran '.$registration_number.' tidak ditemukan.';
					} else {
						$file_name = 'formulir-penerimaan-'. ($this->session->school_level >= 5 ? 'mahasiswa' : 'peserta-didik').'-baru-tahun-'.$this->session->admission_year;
						$file_name .= '-'.$birth_date.'-'.$registration_number.'.pdf';
						if (!file_exists(FCPATH.'media_library/students/'.$file_name)) {
							$this->load->library('admission');
							$this->admission->create_pdf($result);
						}
						$this->vars['status'] = 'success';
						$this->vars['file_name'] = $file_name;
					}
				} else {
					$this->vars['status'] = 'error';
					$this->vars['message'] = 'Format data yang anda masukan tidak benar.';
				}
			} else {
				$this->vars['status'] = 'validation_errors';
				$this->vars['message'] = validation_errors();
			}
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
	* Validations Form
	* @access  public
	* @return Boolean
	*/
	private function validation() {
		$this->load->library('form_validation');
		$val = $this->form_validation;
		$val->set_rules('registration_number', 'Nomor Pendaftaran', 'trim|required|numeric|max_length[10]|min_length[10]');
		$val->set_rules('birth_date', 'Tanggal Lahir', 'trim|required|callback_date_format_check');
		$val->set_message('required', '{field} harus diisi');
		$val->set_error_delimiters('<div>&sdot; ', '</div>');
		return $val->run();
	}

	/**
	* Declaration Check
	* @return Boolean
	*/
	public function date_format_check($str) {
		if (!is_valid_date($str)) {
			$this->form_validation->set_message('date_format_check', 'Tanggal lahir harus diisi engan format YYYY-MM-DD');
			return false;
		}
		return true;
	}
}
