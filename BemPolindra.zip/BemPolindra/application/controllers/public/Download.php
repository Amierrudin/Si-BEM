<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * CMS Sekolahku | CMS (Content Management System) dan PPDB/PMB Online GRATIS
 * untuk sekolah SD/Sederajat, SMP/Sederajat, SMA/Sederajat, dan Perguruan Tinggi
 * @version    2.3.0
 * @author     Anton Sofyan | https://facebook.com/antonsofyan | 4ntonsofyan@gmail.com | 0857 5988 8922
 * @copyright  (c) 2014-2019
 * @link       http://sekolahku.web.id
 *
 * PERINGATAN :
 * 1. TIDAK DIPERKENANKAN MEMPERJUALBELIKAN APLIKASI INI TANPA SEIZIN DARI PIHAK PENGEMBANG APLIKASI.
 * 2. TIDAK DIPERKENANKAN MENGHAPUS KODE SUMBER APLIKASI.
 * 3. TIDAK MENYERTAKAN LINK KOMERSIL (JASA LAYANAN HOSTING DAN DOMAIN) YANG MENGUNTUNGKAN SEPIHAK.
 */

class Download extends Public_Controller {

	/**
	 * Total Rows
	 */
	public $total_rows = 0;

	/**
	 * Total Page
	 */
	public $total_pages = 0;

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
		$this->load->model('public/m_files');
		$this->total_rows = $this->m_files->total_rows($this->uri->segment(2)); // @param slug
		$this->total_pages = ceil($this->total_rows / 20);
	}

	/**
	 * Index
	 * @return Void
	 */
	public function index() {
		$slug = $this->uri->segment(2);
		if (alpha_dash($slug)) {
			$this->vars['page_title'] = strtoupper(str_replace('-', ' ', $slug));
			$this->vars['total_pages'] = $this->total_pages;
			$this->vars['query'] = $this->m_files->get_files($slug);
			$this->vars['content'] = 'themes/'.theme_folder().'/loop-files';
			$this->load->view('themes/'.theme_folder().'/index', $this->vars);
		} else {
			show_404();
		}
	}

	/**
	 * More Files
	 */
	public function more_files() {
		$slug = $this->input->post('slug', true);
		$page_number = (int) $this->input->post('page_number', true);
		$offset = ($page_number - 1) * 20;
		if (alpha_dash($slug)) {
			$query = $this->m_files->get_files($slug, $offset);
			$this->vars['rows'] = $query->result();
		}

		$this->output
			->set_content_type('application/json', 'utf-8')
			->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
			->_display();
		exit;
	}

	/**
	 * force_download
	 */
	public function force_download() {
		$id = (int) $this->uri->segment(4);
		if (_isInteger( $id )) {
			$this->load->helper(['download', 'text']);
			$query = $this->model->RowObject('id', $id, 'files');
			if ($query->file_visibility == 'private' && ! $this->auth->hasLogin()) {
				show_404();
			}
			$data = file_get_contents("./media_library/files/" . $query->file_name);
			$name = url_title(strtolower($query->file_title), '-'). $query->file_ext;
			$this->db->query("UPDATE files SET file_counter = file_counter + 1 WHERE id = '$id'");
			force_download($name, $data);
		} else {
			show_404();
		}
	}
}
