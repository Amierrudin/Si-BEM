<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * CMS Sekolahku | CMS (Content Management System) dan PPDB/PMB Online GRATIS
 * untuk sekolah SD/Sederajat, SMP/Sederajat, SMA/Sederajat, dan Perguruan Tinggi
 * @version    2.3.0
 * @author     Anton Sofyan | https://facebook.com/antonsofyan | 4ntonsofyan@gmail.com | 0857 5988 8922
 * @copyright  (c) 2014-2019
 * @link       http://sekolahku.web.id
 *
 * PERINGATAN :
 * 1. TIDAK DIPERKENANKAN MEMPERJUALBELIKAN APLIKASI INI TANPA SEIZIN DARI PIHAK PENGEMBANG APLIKASI.
 * 2. TIDAK DIPERKENANKAN MENGHAPUS KODE SUMBER APLIKASI.
 * 3. TIDAK MENYERTAKAN LINK KOMERSIL (JASA LAYANAN HOSTING DAN DOMAIN) YANG MENGUNTUNGKAN SEPIHAK.
 */

class Posts extends Admin_Controller {

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
		$this->load->model([
			'm_posts',
			'm_post_categories'
		]);
		$this->pk = M_posts::$pk;
		$this->table = M_posts::$table;
	}

	/**
	 * Index
	 * @return Void
	 */
	public function index() {
		$this->vars['title'] = 'Tulisan';
		$this->vars['posts'] = TRUE;
		$this->vars['content'] = 'posts/member_read';
		$this->load->view('backend/index', $this->vars);
	}

	/**
	 * Add new
	 * @return Void
	 */
	public function create() {
		$this->load->helper('form');
		$id = $this->uri->segment(3);
		if (_isInteger( $id )) {
			$this->vars['query'] = $this->model->RowObject($this->pk, $id, $this->table);
			$post_image = 'media_library/posts/medium/'.$this->vars['query']->post_image;
			$this->vars['post_image'] = file_exists(FCPATH . $post_image) ? base_url($post_image) : '';
			// Check Authorization
			if ((int) $this->vars['query']->post_author !== (int) $this->session->user_id) {
				redirect('dashboard', 'refresh');
			}
			// If has published, forbidden to edit
			if ($this->vars['query']->post_status === 'publish') {
				redirect('dashboard', 'refresh');
			}
		} else {
			$this->vars['query'] = FALSE;
		}
		$this->vars['option_categories'] = $this->m_post_categories->get_post_categories();
		$this->vars['title'] = _isInteger($id) ? 'Edit Tulisan' : 'Tambah Tulisan';
		$this->vars['posts'] = TRUE;
		$this->vars['action'] = site_url('posts/save/'.$id);
		$this->vars['content'] = 'posts/member_create';
		$this->load->view('backend/index', $this->vars);
	}

	/**
	 * Pagination
	 * @return Object
	 */
	public function pagination() {
		if ($this->input->is_ajax_request()) {
			$keyword = trim($this->input->post('keyword', true));
			$page_number = (int) $this->input->post('page_number', true);
			$limit = (int) $this->input->post('per_page', true);
			$offset = ($page_number * $limit);
			$query = $this->m_posts->get_where($keyword, $limit, $offset);
			$total_rows = $this->m_posts->total_rows($keyword);
			$total_page = $limit > 0 ? ceil($total_rows / $limit) : 1;
			$this->vars['total_page'] = (int) $total_page;
			$this->vars['total_rows'] = (int) $total_rows;
			$this->vars['rows'] = $query->result();
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
	 * Find by ID
	 * @return Object
	 */
	public function find_id() {
		if ($this->input->is_ajax_request()) {
			$id = (int) $this->input->post('id', true);
			$query = _isInteger( $id ) ? $this->model->RowObject($this->pk, $id, $this->table) : [];
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($query, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
	 * Save | Update
	 * @return Object
	 */
	public function save() {
		if ($this->input->is_ajax_request()) {
			$id = (int) $this->uri->segment(3);
			if ($this->validation()) {
				$fill_data = $this->fill_data();
				$error_message = '';
				if (!empty($_FILES['post_image'])) {
					$upload = $this->upload_image($id);
					if ($upload['status'] == 'success') {
						$fill_data['post_image'] = $upload['file_name'];
					} else {
						$error_message = $upload['message'];
					}
				}
				if ( !empty( $error_message )) {
					$this->vars['status'] = 'error';
					$this->vars['message'] = $error_message;
				} else {
					$fill_data[(_isInteger( $id ) ? 'updated_by' : 'created_by')] = $this->session->user_id;
					if (!_isInteger( $id )) $fill_data['created_at'] = date('Y-m-d H:i:s');
					if (_isInteger( $id )) unset($fill_data['post_author']);
					$query = $this->model->upsert($id, $this->table, $fill_data);
					$this->vars['action'] = _isInteger( $id ) ? 'update' : 'insert';
					$this->vars['status'] = $query ? 'success' : 'error';
					$this->vars['message'] = $query ? 'Data Anda berhasil disimpan.' : 'Terjadi kesalahan dalam menyimpan data';
				}
			} else {
				$this->vars['status'] = 'error';
				$this->vars['message'] = validation_errors();
			}
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
	 * Fill Data
	 * @return Array
	 */
	private function fill_data() {
		return [
			'post_title' => $this->input->post('post_title', true),
			'post_content' => $this->input->post('post_content'),
			'post_author' => $this->session->user_id,
			'post_categories' => $this->input->post('post_categories', true),
			'post_type' => 'post',
			'post_slug' => slugify($this->input->post('post_title', true))
		];
	}

	/**
	 * Validation Form
	 * @return Boolean
	 */
	private function validation() {
		$this->load->library('form_validation');
		$val = $this->form_validation;
		$val->set_rules('post_title', 'Title', 'trim|required');
		$val->set_rules('post_content', 'Content', 'trim|required');
		$val->set_error_delimiters('<div>&sdot; ', '</div>');
		return $val->run();
	}
}
