<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * CMS Sekolahku | CMS (Content Management System) dan PPDB/PMB Online GRATIS
 * untuk sekolah SD/Sederajat, SMP/Sederajat, SMA/Sederajat, dan Perguruan Tinggi
 * @version    2.3.0
 * @author     Anton Sofyan | https://facebook.com/antonsofyan | 4ntonsofyan@gmail.com | 0857 5988 8922
 * @copyright  (c) 2014-2019
 * @link       http://sekolahku.web.id
 *
 * PERINGATAN :
 * 1. TIDAK DIPERKENANKAN MEMPERJUALBELIKAN APLIKASI INI TANPA SEIZIN DARI PIHAK PENGEMBANG APLIKASI.
 * 2. TIDAK DIPERKENANKAN MENGHAPUS KODE SUMBER APLIKASI.
 * 3. TIDAK MENYERTAKAN LINK KOMERSIL (JASA LAYANAN HOSTING DAN DOMAIN) YANG MENGUNTUNGKAN SEPIHAK.
 */

class Academic_years extends Admin_Controller {

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
		$this->load->model('m_academic_years');
		$this->pk = M_academic_years::$pk;
		$this->table = M_academic_years::$table;
	}

	/**
	 * Index
	 * @return Void
	 */
	public function index() {
		$this->vars['title'] = $this->session->_academic_year;
		$this->vars['academic'] = $this->vars['academic_references'] = $this->vars['academic_years'] = true;
		$this->vars['content'] = 'academic_years/read';
		$this->load->view('backend/index', $this->vars);
	}

	/**
	 * Pagination
	 * @return Object
	 */
	public function pagination() {
		if ($this->input->is_ajax_request()) {
			$keyword = trim($this->input->post('keyword', true));
			$page_number = (int) $this->input->post('page_number', true);
			$limit = (int) $this->input->post('per_page', true);
			$offset = ($page_number * $limit);
			$query = $this->m_academic_years->get_where($keyword, $limit, $offset);
			$total_rows = $this->m_academic_years->total_rows($keyword);
			$total_page = $limit > 0 ? ceil($total_rows / $limit) : 1;
			$this->vars['total_page'] = (int) $total_page;
			$this->vars['total_rows'] = (int) $total_rows;
			$this->vars['rows'] = $query->result();
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
	 * Find by ID
	 * @return Object
	 */
	public function find_id() {
		if ($this->input->is_ajax_request()) {
			$id = (int) $this->input->post('id', true);
			$query = _isInteger( $id ) ? $this->model->RowObject($this->pk, $id, $this->table) : [];
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($query, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
	 * Save | Update
	 * @return Object
	 */
	public function save() {
		if ($this->input->is_ajax_request()) {
			$id = (int) $this->input->post('id', true);
			if ($this->validation()) {
				$fill_data = $this->fill_data();
				if (_isInteger( $id )) {
					$fill_data['updated_by'] = $this->session->user_id;
					$this->vars['status'] = $this->model->update($id, $this->table, $fill_data) ? 'success' : 'error';
					$this->vars['message'] = $this->vars['status'] == 'success' ? 'updated' : 'not_updated';
					if ($this->vars['status'] == 'success' && $fill_data['current_semester'] == 'true') {
						$this->m_academic_years->set_not_active($id, 'current_semester');
					}
					if ($this->vars['status'] == 'success' && $fill_data['admission_semester'] == 'true') {
						$this->m_academic_years->set_not_active($id, 'admission_semester');
					}
				} else {
					if ($fill_data['current_semester'] == 'true') {
						$this->m_academic_years->set_not_active(0, 'current_semester');
					}
					if ($fill_data['admission_semester'] == 'true') {
						$this->m_academic_years->set_not_active(0, 'admission_semester');
					}
					$fill_data['created_by'] = $this->session->user_id;
					$this->vars['status'] = $this->model->insert($this->table, $fill_data) ? 'success' : 'error';
					$this->vars['message'] = $this->vars['status'] == 'success' ? 'created' : 'not_created';
				}
			} else {
				$this->vars['status'] = 'error';
				$this->vars['message'] = validation_errors();
			}
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
	 * Fill Data
	 * @return Array
	 */
	private function fill_data() {
		return [
			'academic_year' => $this->input->post('academic_year', true),
			'semester' => $this->input->post('semester', true),
			'current_semester' => $this->input->post('current_semester', true),
			'admission_semester' => $this->input->post('admission_semester', true)
		];
	}

	/**
	 * Validation Form
	 * @return Boolean
	 */
	private function validation() {
		$this->load->library('form_validation');
		$val = $this->form_validation;
		$val->set_rules('academic_year', 'Academic Years', 'trim|required|min_length[9]|max_length[9]|callback_format_check');
		$val->set_rules('semester', 'Semester', 'trim|required');
		$val->set_rules('current_semester', 'Semester Aktif', 'trim|required|in_list[true,false]');
		$val->set_rules('admission_semester', 'Semester PPDB/PMB', 'trim|required|in_list[true,false]');
		$val->set_error_delimiters('<div>&sdot; ', '</div>');
		return $val->run();
	}

	/**
	 * Format Check
	 * @param 	String
	 * @return 	Boolean
	 */
	public function format_check($val) {
		$year = explode('-', substr($val, 0, 9));
		if (strpos($val, '-') === FALSE) {
			$this->form_validation->set_message('format_check', 'Tahun awal dan tahun akhir harus dipisah dengan tanda strip (-)');
			return FALSE;
		} else if (strlen($val) !== 9) {
			$this->form_validation->set_message('format_check', 'Format tahun pelajaran harus 9 digit. Contoh : 2017-2018');
			return FALSE;
		} else if ((int) $year[ 0 ] === 0 || (int) $year[ 1 ] === 0) {
			$this->form_validation->set_message('format_check', 'Format tahun pelajaran harus diisi angka. Contoh : 2017-2018');
			return FALSE;
		} else if (($year[1] - $year[0]) != 1) {
			$this->form_validation->set_message('format_check', 'Tahun awal dan tahun akhir harus selisih satu !');
			return FALSE;
		} else if (strlen($year[0]) != 4 && strlen($ta[1] != 4)) {
			$this->form_validation->set_message('format_check', 'Tahun harus 4 karakter !');
			return FALSE;
		}
		return TRUE;
	}
}
