<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * CMS Sekolahku | CMS (Content Management System) dan PPDB/PMB Online GRATIS
 * untuk sekolah SD/Sederajat, SMP/Sederajat, SMA/Sederajat, dan Perguruan Tinggi
 * @version    2.3.0
 * @author     Anton Sofyan | https://facebook.com/antonsofyan | 4ntonsofyan@gmail.com | 0857 5988 8922
 * @copyright  (c) 2014-2019
 * @link       http://sekolahku.web.id
 *
 * PERINGATAN :
 * 1. TIDAK DIPERKENANKAN MEMPERJUALBELIKAN APLIKASI INI TANPA SEIZIN DARI PIHAK PENGEMBANG APLIKASI.
 * 2. TIDAK DIPERKENANKAN MENGHAPUS KODE SUMBER APLIKASI.
 * 3. TIDAK MENYERTAKAN LINK KOMERSIL (JASA LAYANAN HOSTING DAN DOMAIN) YANG MENGUNTUNGKAN SEPIHAK.
 */

class Import_alumni extends Admin_Controller {

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
		$this->load->model('m_options');
	}

	/**
	 * Index
	 * @return Void
	 */
	public function index() {
		$this->vars['title'] = 'Import Alumni';
		$this->vars['academic'] = $this->vars['academic_import'] = $this->vars['import_alumni'] = true;
		$this->vars['content'] = 'alumni/import_alumni';
		$this->load->view('backend/index', $this->vars);
	}

	/**
	 * Save
	 */
	public function save() {
		if ($this->input->is_ajax_request()) {
			$rows = explode("\n", $this->input->post('students'));
			$success = $failed = $exist = 0;
			foreach($rows as $row) {
				$exp = explode("\t", $row);
				if (count($exp) != 8) continue;
				$fill_data = [];
				$fill_data['identity_number'] = trim($exp[0]);
				$fill_data['full_name'] = trim($exp[1]);
				$fill_data['gender'] = trim($exp[2]) == 'L' ? 'M' : 'F';
				$fill_data['start_date'] = trim($exp[3]);
				$fill_data['end_date'] = trim($exp[4]);
				$fill_data['mobile_phone'] = trim($exp[5]);
				$fill_data['email'] = trim($exp[6]);
				$fill_data['street_address'] = trim($exp[7]);
				$fill_data['is_transfer'] = 'false';
				$fill_data['is_prospective_student'] = 'false';
				$fill_data['is_alumni'] = 'true';
				$fill_data['is_student'] = 'false';
				$fill_data['citizenship'] = 'WNI';
				$fill_data['student_status_id'] = $this->m_options->get_option_id('student_status', 'lulus');
				$key_exists = $this->model->is_exists('identity_number', trim($exp[0]), 'students');
				$email_exists = $this->model->is_exists('identity_number', trim($exp[6]), 'students');
				if (!$key_exists && !$email_exists) {
					$this->model->insert('students', $fill_data) ? $success++ : $failed++;
				} else {
					$exist++;
				}
			}
			$this->vars['status'] = 'info';
			$this->vars['message'] = 'Success : ' . $success. ' rows, Failed : '. $failed .', Exist : ' . $exist;
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}
}
