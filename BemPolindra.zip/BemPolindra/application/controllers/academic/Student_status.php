<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * CMS Sekolahku | CMS (Content Management System) dan PPDB/PMB Online GRATIS
 * untuk sekolah SD/Sederajat, SMP/Sederajat, SMA/Sederajat, dan Perguruan Tinggi
 * @version    2.3.0
 * @author     Anton Sofyan | https://facebook.com/antonsofyan | 4ntonsofyan@gmail.com | 0857 5988 8922
 * @copyright  (c) 2014-2019
 * @link       http://sekolahku.web.id
 *
 * PERINGATAN :
 * 1. TIDAK DIPERKENANKAN MEMPERJUALBELIKAN APLIKASI INI TANPA SEIZIN DARI PIHAK PENGEMBANG APLIKASI.
 * 2. TIDAK DIPERKENANKAN MENGHAPUS KODE SUMBER APLIKASI.
 * 3. TIDAK MENYERTAKAN LINK KOMERSIL (JASA LAYANAN HOSTING DAN DOMAIN) YANG MENGUNTUNGKAN SEPIHAK.
 */

class Student_status extends Admin_Controller {

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
		$this->load->model('m_options');
		$this->pk = M_options::$pk;
		$this->table = M_options::$table;
	}

	/**
	* Index
	*
	* @return	void
	*/
	public function index() {
		$this->vars['title'] = 'Status ' . ucwords(strtolower($this->session->_student));
		$this->vars['academic'] = $this->vars['academic_references'] = $this->vars['student_status'] = true;
		$this->vars['content'] = 'options/student_status';
		$this->load->view('backend/index', $this->vars);
	}

	/**
	* Pagination
	*
	* @return	Json
	*/
	public function pagination() {
		if ($this->input->is_ajax_request()) {
			$keyword = trim($this->input->post('keyword', true));
			$page_number = (int) $this->input->post('page_number', true);
			$limit = (int) $this->input->post('per_page', true);
			$offset = ($page_number * $limit);
			$query = $this->m_options->get_where($keyword, $limit, $offset, 'student_status');
			$total_rows = $this->m_options->total_rows($keyword, 'student_status');
			$total_page = $limit > 0 ? ceil($total_rows / $limit) : 1;
			$this->vars['total_page'] = (int) $total_page;
			$this->vars['total_rows'] = (int) $total_rows;
			$this->vars['rows'] = $query->result();
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}

	}

	/**
	* Find by ID
	* @return 	Void
	*/
	public function find_id() {
		if ($this->input->is_ajax_request()) {
			$id = (int) $this->input->post('id', true);
			$query = _isInteger( $id ) ? $this->model->RowObject($this->pk, $id, $this->table) : [];
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($query, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
	* Save or Update
	* @return 	Object
	*/
	public function save() {
		if ($this->input->is_ajax_request()) {
			$id = (int) $this->input->post('id', true);
			if ($this->validation()) {
				$fill_data = $this->fill_data();
				if (_isInteger( $id )) {
					$query = $this->model->RowObject($this->pk, $id, $this->table);
					if (!in_array(strtolower($query->option_name), ['lulus', 'aktif'])) {
						$fill_data['updated_by'] = $this->session->user_id;
						$this->vars['status'] = $this->model->update($id, $this->table, $fill_data) ? 'success' : 'error';
						$this->vars['message'] = $this->vars['status'] == 'success' ? 'updated' : 'not_updated';
					} else {
						$this->vars['status'] = 'info';
						$this->vars['message'] = 'Status peserta didik Lulus dan Aktif tidak dapat diubah !';
					}
				} else {
					if (!in_array(strtolower($fill_data['option_name']), ['lulus', 'aktif'])) {
						$fill_data['created_at'] = date('Y-m-d H:i:s');
						$fill_data['created_by'] = $this->session->user_id;
						$this->vars['status'] = $this->model->insert($this->table, $fill_data) ? 'success' : 'error';
						$this->vars['message'] = $this->vars['status'] == 'success' ? 'created' : 'not_created';
					} else {
						$this->vars['status'] = 'info';
						$this->vars['message'] = 'Status peserta didik '. strtoupper($fill_data['option_name']) .' sudah ada !';
					}
				}
			} else {
				$this->vars['status'] = 'error';
				$this->vars['message'] = validation_errors();
			}
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
	* Fill Data
	* @return Array
	*/
	private function fill_data() {
		return [
			'option_group' => 'student_status',
			'option_name' => $this->input->post('option_name', true)
		];
	}

	/**
	* Validations Form
	* @return Bool
	*/
	private function validation() {
		$this->load->library('form_validation');
		$val = $this->form_validation;
		$val->set_rules('option_name', 'Status ' . $this->session->_student, 'trim|required');
		$val->set_message('required', '{field} harus diisi');
		$val->set_error_delimiters('<div>&sdot; ', '</div>');
		return $val->run();
	}
}
