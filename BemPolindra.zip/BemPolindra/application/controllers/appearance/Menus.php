<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * CMS Sekolahku | CMS (Content Management System) dan PPDB/PMB Online GRATIS
 * untuk sekolah SD/Sederajat, SMP/Sederajat, SMA/Sederajat, dan Perguruan Tinggi
 * @version    2.3.0
 * @author     Anton Sofyan | https://facebook.com/antonsofyan | 4ntonsofyan@gmail.com | 0857 5988 8922
 * @copyright  (c) 2014-2019
 * @link       http://sekolahku.web.id
 *
 * PERINGATAN :
 * 1. TIDAK DIPERKENANKAN MEMPERJUALBELIKAN APLIKASI INI TANPA SEIZIN DARI PIHAK PENGEMBANG APLIKASI.
 * 2. TIDAK DIPERKENANKAN MENGHAPUS KODE SUMBER APLIKASI.
 * 3. TIDAK MENYERTAKAN LINK KOMERSIL (JASA LAYANAN HOSTING DAN DOMAIN) YANG MENGUNTUNGKAN SEPIHAK.
 */

class Menus extends Admin_Controller {

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
		$this->load->model('m_menus');
		$this->pk = M_menus::$pk;
		$this->table = M_menus::$table;
	}

	/**
	 * Index
	 * @return Void
	 */
	public function index() {
		$this->vars['title'] = 'Menu';
		$this->vars['appearance'] = $this->vars['menus'] = true;
		$this->vars['content'] = 'menus/read';
		$this->load->view('backend/index', $this->vars);
	}

	/**
	 * Get All Menus
	 * @return Object
	 */
	public function get_menus() {
		if ($this->input->is_ajax_request()) {
			$query = $this->m_menus->get_menus();
			$this->vars['rows'] = $query->result();
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
	 * Delete Menus
	 * @param 	Int
	 * @return 	Object
	 */
	public function delete_permanently() {
		if ($this->input->is_ajax_request()) {
			$id = (int) $this->input->post('id', true);
			if (_isInteger( $id )) {
				$is_exists = $this->model->is_exists('menu_parent_id', $id, $this->table);
				if ( ! $is_exists ) {
					$this->model->delete_permanently($this->pk, $id, $this->table);
					$this->vars['status'] = $this->model->delete_permanently($this->pk, $id, $this->table) ? 'success' : 'error';
					$this->vars['message'] = $this->vars['status'] == 'success' ? 'deleted' : 'not_deleted';
				} else {
					$this->vars['status'] = 'warning';
					$this->vars['message'] = '"Parent menu" tidak dapat dihapus. Silahkan hapus terlebih dahulu "child menu"!';
				}
			} else {
				$this->vars['status'] = 'error';
				$this->vars['message'] = 'Not initialize id OR id not a number';
			}

			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
	 * Truncate table menus
	 * @return Object
	 */
	public function truncate_table() {
		if ($this->input->is_ajax_request()) {
			$this->vars['status'] = $this->model->truncate($this->table) ? 'success' : 'error';
			$this->vars['message'] = $this->vars['status'] == 'success' ? 'deleted' : 'not_deleted';
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
	 * Get Nested List Menus
	 * @return Object
	 */
	public function nested_list() {
		if ($this->input->is_ajax_request()) {
			$query = $this->m_menus->parent_menus();
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($query, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

   /**
    * Save menu position
    * @return Object
    */
   public function save_positions() {
   	if ($this->input->is_ajax_request()) {
			if (NULL !== $this->input->post('menus')) {
				$menus = json_decode($this->input->post('menus'), true);
				$this->m_menus->save_positions(0, $menus);
			}
			$this->vars['status'] = 'success';
			$this->vars['message'] = 'Your data have been saved.';
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}

   }

	/**
    * Get All Pages
    * @return Object
    */
	public function get_pages() {
		if ($this->input->is_ajax_request()) {
			$this->load->model('m_pages');
			$query = $this->m_pages->get_pages();
			$this->vars['rows'] = $query->result();
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
    * Get All Post Categories
    * @return Object
    */
	public function get_post_categories() {
		if ($this->input->is_ajax_request()) {
			$this->load->model('m_post_categories');
			$query = $this->m_post_categories->get_post_categories();
			$rows = [];
			foreach($query->result() as $row) {
				$rows[] = [
					'id' => $row->id,
					'category_name' => $row->category_name
				];
			}
			$this->vars['rows'] = $rows;
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
    * Get All File Categories
    * @return Object
    */
	public function get_file_categories() {
		if ($this->input->is_ajax_request()) {
			$this->load->model('m_file_categories');
			$query = $this->m_file_categories->get_file_categories();
			$rows = [];
			foreach($query->result() as $row) {
				$rows[] = [
					'id' => $row->id,
					'category_name' => $row->category_name
				];
			}
			$this->vars['rows'] = $rows;
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
    * Save Custom Links
    * @return Object
    */
	public function save_links() {
		if ($this->input->is_ajax_request()) {
			$fill_data = [
				'menu_url' => ($this->input->post('menu_url', true) && $this->input->post('menu_url', true) != '#') ? prep_url($this->input->post('menu_url', true)) : '#',
				'menu_title' => $this->input->post('menu_title', true),
				'menu_target' => $this->input->post('menu_target', true),
				'menu_type' => 'link'
			];
			$this->vars['status'] = $this->model->insert($this->table, $fill_data) ? 'success' : 'error';
			$this->vars['message'] = $this->vars['status'] == 'success' ? 'created' : 'not_created';
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
    * Save Menus From Pages
    * @return Object
    */
	public function save_pages() {
		if ($this->input->is_ajax_request()) {
			$ids = explode(',', $this->input->post('ids'));
			foreach($ids as $id) {
				$query = $this->model->RowObject('id', $id, 'posts');
				$fill_data = [
					'menu_title' => $query->post_title,
					'menu_url' => 'read/' . $id . '/'.$query->post_slug,
					'menu_type' => 'page',
					'menu_target' => '_self'
				];
				$this->model->insert('menus', $fill_data);
			}
			$this->vars['status'] = 'success';
			$this->vars['message'] = 'created';
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
    * Save Menus From Posts Categories
    * @return Object
    */
	public function save_post_categories() {
		if ($this->input->is_ajax_request()) {
			$ids = explode(',', $this->input->post('ids'));
			foreach($ids as $id) {
				$query = $this->model->RowObject('id', $id, 'categories');
				$fill_data = [
					'menu_title' => $query->category_name,
					'menu_url' => 'category/'.$query->category_slug,
					'menu_type' => 'post_category',
					'menu_target' => '_self'
				];
				$this->model->insert('menus', $fill_data);
			}
			$this->vars['status'] = 'success';
			$this->vars['message'] = 'created';
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
    * Save Menus From File Categories
    * @return Object
    */
	public function save_file_categories() {
		if ($this->input->is_ajax_request()) {
			$ids = explode(',', $this->input->post('ids'));
			foreach($ids as $id) {
				$query = $this->model->RowObject('id', $id, 'categories');
				$fill_data = [
					'menu_title' => $query->category_name,
					'menu_url' => 'download/'.$query->category_slug,
					'menu_type' => 'file_category',
					'menu_target' => '_self'
				];
				$this->model->insert('menus', $fill_data);
			}
			$this->vars['status'] = 'success';
			$this->vars['message'] = 'created';
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
    * Save Menus From List Modules
    * @return Object
    */
	public function save_modules() {
		if ($this->input->is_ajax_request()) {
			$modules = explode(',', $this->input->post('modules'));
			foreach($modules as $module) {
				$fill_data = [
					'menu_title' => modules($module),
					'menu_url' => $module,
					'menu_type' => 'module',
					'menu_target' => '_self'
				];
				$this->model->insert('menus', $fill_data);
			}
			$this->vars['status'] = 'success';
			$this->vars['message'] = 'created';
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
	 * Find by ID
	 * @return Object
	 */
	public function find_id() {
		if ($this->input->is_ajax_request()) {
			$id = (int) $this->input->post('id', true);
			$query = _isInteger( $id ) ? $this->model->RowObject($this->pk, $id, $this->table) : [];
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($query, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
	 * Save | Update
	 * @return Object
	 */
	public function save() {
		if ($this->input->is_ajax_request()) {
			$id = (int) $this->input->post('id', true);
			if ($this->validation()) {
				$fill_data = $this->fill_data();
				$fill_data['updated_by'] = $this->session->user_id;
				$this->vars['status'] = $this->model->update($id, $this->table, $fill_data) ? 'success' : 'error';
				$this->vars['message'] = $this->vars['status'] == 'success' ? 'updated' : 'not_updated';
			} else {
				$this->vars['status'] = 'error';
				$this->vars['message'] = validation_errors();
			}
			$this->output
				->set_content_type('application/json', 'utf-8')
				->set_output(json_encode($this->vars, JSON_PRETTY_PRINT))
				->_display();
			exit;
		}
	}

	/**
	 * Fill Data
	 * @return Array
	 */
	private function fill_data() {
		$data = [];
		$data['menu_title'] = $this->input->post('menu_title', true);
		$data['menu_url'] = $this->input->post('menu_url', true);
		$data['menu_target'] = $this->input->post('menu_target', true);
		$is_deleted = $this->input->post('is_deleted');
		$data['is_deleted'] = $is_deleted;
		if ($is_deleted == 'true') {
			$data['deleted_by'] = $this->session->user_id;
			$data['deleted_at'] = date('Y-m-d H:i:s');
		} else {
			$data['restored_by'] = $this->session->user_id;
			$data['restored_at'] = date('Y-m-d H:i:s');
		}
		return $data;
	}

	/**
	 * Validation Form
	 * @return Boolean
	 */
	private function validation() {
		$this->load->library('form_validation');
		$val = $this->form_validation;
		$val->set_rules('menu_title', 'Title', 'trim|required');
		$val->set_rules('menu_url', 'URL', 'trim|required');
		$val->set_rules('menu_target', 'Target', 'trim|required');
		$val->set_rules('is_deleted', 'Aktif ?', 'trim|required|in_list[true,false]');
		$val->set_error_delimiters('<div>&sdot; ', '</div>');
		return $val->run();
	}
}
