<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * CMS Sekolahku | CMS (Content Management System) dan PPDB/PMB Online GRATIS
 * untuk sekolah SD/Sederajat, SMP/Sederajat, SMA/Sederajat, dan Perguruan Tinggi
 * @version    2.3.0
 * @author     Anton Sofyan | https://facebook.com/antonsofyan | 4ntonsofyan@gmail.com | 0857 5988 8922
 * @copyright  (c) 2014-2019
 * @link       http://sekolahku.web.id
 *
 * PERINGATAN :
 * 1. TIDAK DIPERKENANKAN MEMPERJUALBELIKAN APLIKASI INI TANPA SEIZIN DARI PIHAK PENGEMBANG APLIKASI.
 * 2. TIDAK DIPERKENANKAN MENGHAPUS KODE SUMBER APLIKASI.
 * 3. TIDAK MENYERTAKAN LINK KOMERSIL (JASA LAYANAN HOSTING DAN DOMAIN) YANG MENGUNTUNGKAN SEPIHAK.
 */

/**
 * Get Active Theme
 */
if (! function_exists('theme_folder')) {
	function theme_folder() {
		$CI = &get_instance();
		return $CI->session->userdata('theme');
	}
}

/**
 * Get Links
 * @param Int $limit
 * @return Resource
 */
if (! function_exists('get_links')) {
	function get_links( $limit = 0 ) {
		$CI = &get_instance();
		$CI->load->model('public/m_links');
		return $CI->m_links->get_links($limit);
	}
}

/**
 * Get Tags
 * @param Int $limit
 * @return Resource
 */
if (! function_exists('get_tags')) {
	function get_tags( $limit = 10 ) {
		$CI = &get_instance();
		$CI->load->model('public/m_tags');
		return $CI->m_tags->get_tags( $limit, TRUE);
	}
}

/**
 * Get Banners
 * @param Int $limit
 * @return Resource
 */
if (! function_exists('get_banners')) {
	function get_banners( $limit = 0 ) {
		$CI = &get_instance();
		$CI->load->model('public/m_banners');
		return $CI->m_banners->get_banners($limit);
	}
}

/**
 * Get Archive Year
 */
if (! function_exists('get_archive_year')) {
	function get_archive_year() {
		$CI = &get_instance();
		$CI->load->model('public/m_posts');
		return $CI->m_posts->get_archive_year();
	}
}

/**
 * Get Archive
 * @param Int
 */
if (! function_exists('get_archives')) {
	function get_archives($year) {
		$CI = &get_instance();
		$CI->load->model('public/m_posts');
		return $CI->m_posts->get_archives($year);
	}
}

/**
 * Get Quotes
 */
if (! function_exists('get_quotes')) {
	function get_quotes( $limit = 0 ) {
		$CI = &get_instance();
		$CI->load->model('public/m_quotes');
		return $CI->m_quotes->get_quotes( $limit );
	}
}

/**
 * Get Image Sliders
 * @param Int $limit
 * @return Resource
 */
if (! function_exists('get_image_sliders')) {
	function get_image_sliders( $limit = 0 ) {
		$CI = &get_instance();
		$CI->load->model('public/m_image_sliders');
		return $CI->m_image_sliders->get_image_sliders( $limit );
	}
}

/**
 * Get Question
 */
if (! function_exists('get_active_question')) {
	function get_active_question() {
		$CI = &get_instance();
		$CI->load->model('public/m_questions');
		return $CI->m_questions->get_active_question();
	}
}

/**
 * Get Answears
 * @param Int $question_id
 * @return Resource
 */
if (! function_exists('get_answers')) {
	function get_answers($question_id) {
		$CI = &get_instance();
		$CI->load->model('public/m_answers');
		return $CI->m_answers->get_answers($question_id);
	}
}

/**
 * Get Recent Posts
 * @param Int $limit
 * @return Resource
 */
if (! function_exists('get_recent_posts')) {
	function get_recent_posts( $limit = 0 ) {
		$CI = &get_instance();
		$CI->load->model('public/m_posts');
		return $CI->m_posts->get_recent_posts( $limit );
	}
}

/**
 * Get Popular Posts
 * @param Int $limit
 * @return Resource
 */
if (! function_exists('get_popular_posts')) {
	function get_popular_posts( $limit = 0 ) {
		$CI = &get_instance();
		$CI->load->model('public/m_posts');
		return $CI->m_posts->get_popular_posts( $limit );
	}
}

/**
 * Get Most Commented
 * @param Int $limit
 * @return Resource
 */
if (! function_exists('get_most_commented')) {
	function get_most_commented( $limit = 0 ) {
		$CI = &get_instance();
		$CI->load->model('public/m_posts');
		return $CI->m_posts->get_most_commented( $limit );
	}
}

/**
 * Get Random Posts
 * @param Int $limit
 * @return Resource
 */
if (! function_exists('get_random_posts')) {
	function get_random_posts( $limit = 0 ) {
		$CI = &get_instance();
		$CI->load->model('public/m_posts');
		return $CI->m_posts->get_random_posts( $limit );
	}
}

/**
 * Get post category
 * @param Int $id
 * @param Int $limit
 * @return Resource
 */
if (! function_exists('get_post_category')) {
	function get_post_category($id, $limit = 0) {
		$CI = &get_instance();
		$CI->load->model('public/m_posts');
		return $CI->m_posts->get_post_category($id, $limit);
	}
}

/**
 * Get All Post Categories
 * @param Int $limit
 * @return Resource
 */
if (! function_exists('get_post_categories')) {
	function get_post_categories($limit = 6) {
		$CI = &get_instance();
		$CI->load->model('m_post_categories');
		return $CI->m_post_categories->get_post_categories($limit);
	}
}

/**
 * Get Related Posts
 * @param String $categories
 * @param Int $limit
 * @return Resource
 */
if (! function_exists('get_related_posts')) {
	function get_related_posts($categories, $id) {
		$CI = &get_instance();
		$CI->load->model('public/m_posts');
		return $CI->m_posts->get_related_posts($categories, $id);
	}
}

/**
 * Get Recent Comments
 * @param Int $limit
 * @return Resource
 */
if (! function_exists('get_recent_comments')) {
	function get_recent_comments( $limit = 0 ) {
		$CI = &get_instance();
		$CI->load->model('public/m_post_comments');
		return $CI->m_post_comments->get_recent_comments( $limit );
	}
}

/**
 * Welcome | Sambutan Kepala Sekolah
 * @access  Public
 * @return String
 */
if (! function_exists('get_welcome')) {
	function get_welcome() {
		$CI = &get_instance();
		$CI->load->model('public/m_posts');
		return $CI->m_posts->get_welcome();
	}
}

/**
 * Get Recent Videos
 * @param Int $limit
 * @return Resource
 */
if (! function_exists('get_videos')) {
	function get_videos( $limit = 0 ) {
		$CI = &get_instance();
		$CI->load->model('public/m_videos');
		return $CI->m_videos->get_videos( $limit );
	}
}

/**
 * Get All Albums
 * @param Int $limit
 * @return Resource
 */
if (! function_exists('get_albums')) {
	function get_albums( $limit = 0 ) {
		$CI = &get_instance();
		$CI->load->model('public/m_albums');
		return $CI->m_albums->get_albums( $limit );
	}
}

/**
 * recursive list
 */
if (!function_exists('recursive_list')) {
	function recursive_list($menus) {
		$str = '';
		foreach ($menus as $menu) {
			$url = base_url() . $menu['menu_url'];
			if ($menu['menu_type'] == 'link') {
				$url = $menu['menu_url'];
			}
			$str .= '<li>';
			$subchild = recursive_list($menu['child']);
			$str .= anchor($url, $menu['menu_title'].($subchild?' <span class="caret"></span>':''), 'target="'.$menu['menu_target'].'"');
			if ($subchild) {
				$str .= "<ul class='dropdown-menu'>" . $subchild . "</ul>";
			}
			$str .= "</li>";
		}
		return $str;
	}
}

/**
 * Routes | Forewords From Head
 * @access  Public
 * @return 	String
 */

if (! function_exists('forewords_route')) {
	function forewords_route() {
		$CI = &get_instance();
		$level = (int) $CI->session->school_level;
		if ( $level == 5 ) return 'sambutan-rektor';
		if ( $level == 6 ) return 'sambutan-ketua';
		if ( $level == 7 ) return 'sambutan-direktor';
		return 'sambutan-kepala-sekolah';
	}
}
