<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * CMS Sekolahku | CMS (Content Management System) dan PPDB/PMB Online GRATIS
 * untuk sekolah SD/Sederajat, SMP/Sederajat, SMA/Sederajat, dan Perguruan Tinggi
 * @version    2.3.0
 * @author     Anton Sofyan | https://facebook.com/antonsofyan | 4ntonsofyan@gmail.com | 0857 5988 8922
 * @copyright  (c) 2014-2019
 * @link       http://sekolahku.web.id
 *
 * PERINGATAN :
 * 1. TIDAK DIPERKENANKAN MEMPERJUALBELIKAN APLIKASI INI TANPA SEIZIN DARI PIHAK PENGEMBANG APLIKASI.
 * 2. TIDAK DIPERKENANKAN MENGHAPUS KODE SUMBER APLIKASI.
 * 3. TIDAK MENYERTAKAN LINK KOMERSIL (JASA LAYANAN HOSTING DAN DOMAIN) YANG MENGUNTUNGKAN SEPIHAK.
 */

class M_settings extends CI_Model {

	/**
	 * Primary key
	 * @var String
	 */
	public static $pk = 'id';

	/**
	 * Table
	 * @var String
	 */
	public static $table = 'settings';

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Get Data
	 * @param 	String
	 * @param 	Int
	 * @param 	Int
	 * @return 	Resource
	 */
	public function get_where($keyword, $limit = 0, $offset = 0, $group = 'general') {
		$this->db->select('id, setting_variable, COALESCE(setting_value, setting_default_value) AS setting_value, setting_description, is_deleted');
		$this->db->where('setting_group', $group);
		if (!empty($keyword)) {
			$this->db->group_start();
			$this->db->like('setting_description', $keyword);
			$this->db->or_like('setting_value', $keyword);
			$this->db->group_end();
		}
		if ($limit > 0) $this->db->limit($limit, $offset);
		return $this->db->get(self::$table);
	}

	/**
	 * Get Total Rows
	 * @param 	String
	 * @return Int
	 */
	public function total_rows($keyword, $group) {
		$this->db->where('setting_group', $group);
		if (!empty($keyword)) {
			$this->db->group_start();
			$this->db->like('setting_description', $keyword);
			$this->db->or_like('setting_value', $keyword);
			$this->db->group_end();
		}
		return $this->db->count_all_results(self::$table);
	}

	/**
	 * Get Setting Values
	 * @param array
	 * @return array
	 */
	public function get_setting_values($access_group = 'public') {
		$query = $this->db
			->select('setting_variable, COALESCE(setting_value, setting_default_value) AS setting_value')
			->like('setting_access_group', $access_group)
			->get(self::$table);
		$settings = [];
		foreach($query->result() as $row) {
			$settings[$row->setting_variable] = $row->setting_value;
		}
		return $settings;
	}

	/**
	 * mail_server_settings
	 * @return array
	 */
	function mail_server_settings() {
		$query = $this->db
			->select("setting_variable, COALESCE(setting_value,setting_default_value, '') setting_value")
			->where('setting_group', 'mail_server')
			->get('settings');
		$data = [];
		foreach($query->result() as $row) {
			$data[$row->variable] = $row->setting_value;
		}
		return $data;
	}

	/**
	 * Recaptcha
	 * @return array
	 */
	function get_recaptcha() {
		$query = $this->db
			->select("setting_variable, setting_value")
			->where_in('setting_variable', ['recaptcha_site_key', 'recaptcha_secret_key'])
			->get('settings');
		$data = [];
		$data['recaptcha_site_key'] = NULL;
		$data['recaptcha_secret_key'] = NULL;
		foreach($query->result() as $row) {
			if ($row->setting_variable == 'recaptcha_site_key') {
				$data['recaptcha_site_key'] = $row->setting_value;
			}
			if ($row->setting_variable == 'recaptcha_secret_key') {
				$data['recaptcha_secret_key'] = $row->setting_value;
			}
		}
		return $data;
	}

	/**
	 * Get Sendgrid API Key
	 * @return array
	 */
	public function get_sendgrid_api_key() {
		$query = $this->db
			->select("setting_variable, setting_value")
			->where('setting_variable', 'sendgrid_api_key')
			->get('settings');
		if ($query->num_rows() === 1) {
			$res = $query->row();
			return $res->setting_value ? $res->setting_value : $res->setting_default_value;
		}
		return NULL;
	}
}
