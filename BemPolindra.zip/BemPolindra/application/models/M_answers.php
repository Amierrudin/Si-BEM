<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * CMS Sekolahku | CMS (Content Management System) dan PPDB/PMB Online GRATIS
 * untuk sekolah SD/Sederajat, SMP/Sederajat, SMA/Sederajat, dan Perguruan Tinggi
 * @version    2.3.0
 * @author     Anton Sofyan | https://facebook.com/antonsofyan | 4ntonsofyan@gmail.com | 0857 5988 8922
 * @copyright  (c) 2014-2019
 * @link       http://sekolahku.web.id
 *
 * PERINGATAN :
 * 1. TIDAK DIPERKENANKAN MEMPERJUALBELIKAN APLIKASI INI TANPA SEIZIN DARI PIHAK PENGEMBANG APLIKASI.
 * 2. TIDAK DIPERKENANKAN MENGHAPUS KODE SUMBER APLIKASI.
 * 3. TIDAK MENYERTAKAN LINK KOMERSIL (JASA LAYANAN HOSTING DAN DOMAIN) YANG MENGUNTUNGKAN SEPIHAK.
 */

class M_answers extends CI_Model {

	/**
	 * Primary key
	 * @var String
	 */
	public static $pk = 'id';

	/**
	 * Table
	 * @var String
	 */
	public static $table = 'answers';

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Get data for pagination
	 * @param String
	 * @param Int
	 * @param Int
	 * @return Resource
	 */
	public function get_where($keyword = '', $limit = 0, $offset = 0) {
		$this->db->select('x1.id, x2.question,	x1.answer, x1.is_deleted');
		$this->db->join('questions x2', 'x1.question_id = x2.id', 'LEFT');
		if (!empty($keyword)) {
			$this->db->like('x2.question', $keyword);
			$this->db->or_like('x1.answer', $keyword);
		}
		if ($limit > 0) $this->db->limit($limit, $offset);
		return $this->db->get(self::$table.' x1');
	}

	/**
	 * Get total rows of the resource
	 * @param String $keyword
	 * @return Integer
	 */
	public function total_rows($keyword = '') {
		$this->db->join('questions x2', 'x1.question_id = x2.id', 'LEFT');
		if (!empty($keyword)) {
			$this->db->like('x2.question', $keyword);
			$this->db->or_like('x1.answer', $keyword);
		}
		return $this->db->count_all_results(self::$table .' x1');
	}
}
