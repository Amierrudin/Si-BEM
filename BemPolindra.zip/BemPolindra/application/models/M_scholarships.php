<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * CMS Sekolahku | CMS (Content Management System) dan PPDB/PMB Online GRATIS
 * untuk sekolah SD/Sederajat, SMP/Sederajat, SMA/Sederajat, dan Perguruan Tinggi
 * @version    2.3.0
 * @author     Anton Sofyan | https://facebook.com/antonsofyan | 4ntonsofyan@gmail.com | 0857 5988 8922
 * @copyright  (c) 2014-2019
 * @link       http://sekolahku.web.id
 *
 * PERINGATAN :
 * 1. TIDAK DIPERKENANKAN MEMPERJUALBELIKAN APLIKASI INI TANPA SEIZIN DARI PIHAK PENGEMBANG APLIKASI.
 * 2. TIDAK DIPERKENANKAN MENGHAPUS KODE SUMBER APLIKASI.
 * 3. TIDAK MENYERTAKAN LINK KOMERSIL (JASA LAYANAN HOSTING DAN DOMAIN) YANG MENGUNTUNGKAN SEPIHAK.
 */

class M_scholarships extends CI_Model {

	/**
	 * Primary key
	 * @var String
	 */
	public static $pk = 'id';

	/**
	 * Table
	 * @var String
	 */
	public static $table = 'scholarships';

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Display a listing of the resource.
	 * @param String $keyword
	 * @param Integer $limit
	 * @param Integer $offset
	 * @return Resource
	 */
	public function get_where($keyword = '', $limit = 10, $offset = 0) {
		$this->db->select('id, scholarship_type, scholarship_description, scholarship_start_year, scholarship_end_year, is_deleted');
		if ($this->session->user_type === 'student') $this->db->where('student_id', $this->session->user_profile_id);
		if (!empty($keyword)) {
			$this->db->group_start();
			$this->db->like('scholarship_type', $keyword);
			$this->db->or_like('scholarship_description', $keyword);
			$this->db->or_like('scholarship_start_year', $keyword);
			$this->db->or_like('scholarship_end_year', $keyword);
			$this->db->group_end();
		}
		return $this->db->get(self::$table, $limit, $offset);
	}

	/**
	 * Get total rows of the resource
	 * @param String $keyword
	 * @return Integer
	 */
	public function total_rows($keyword = '') {
		if ($this->session->user_type === 'student') $this->db->where('student_id', $this->session->user_profile_id);
		if (!empty($keyword)) {
			$this->db->group_start();
			$this->db->like('scholarship_type', $keyword);
			$this->db->or_like('scholarship_description', $keyword);
			$this->db->or_like('scholarship_start_year', $keyword);
			$this->db->or_like('scholarship_end_year', $keyword);
			$this->db->group_end();
		}
		return $this->db->count_all_results(self::$table);;
	}

	/**
	 * Get By Student ID
	 * @param Int $student_id
	 * @return Resource
	 */
	public function get_by_student_id($student_id = 0) {
		$this->db->select('id, scholarship_type, scholarship_description, scholarship_start_year, scholarship_end_year, is_deleted');
		$this->db->where('student_id', $student_id);
		$this->db->where('is_deleted', 'false');
		return $this->db->get(self::$table);
	}
}
