<?php defined('BASEPATH') OR exit('No direct script access allowed');



class M_banners extends CI_Model {

	/**
	 * Primary key
	 * @var String
	 */
	public static $pk = 'id';

	/**
	 * Table
	 * @var String
	 */
	public static $table = 'links';

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Get All Banners
	 * @param Int $limit
	 * @return 	Resource
	 */
	public function get_banners($limit = 0) {
		$this->db->select("id, link_title, link_url, link_target, link_image");
		$this->db->where('link_type', 'banner');
		$this->db->where('is_deleted', 'false');
		if ($limit > 0) $this->db->limit($limit);
		return $this->db->get(self::$table);
	}
}
