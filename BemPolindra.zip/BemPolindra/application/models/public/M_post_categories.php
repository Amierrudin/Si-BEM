<?php defined('BASEPATH') OR exit('No direct script access allowed');



class M_post_categories extends CI_Model {

	/**
	 * Primary key
	 * @var String
	 */
	public static $pk = 'id';

	/**
	 * Table
	 * @var String
	 */
	public static $table = 'categories';

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Get All Post Categories
	 * @access public
	 * @return Resource
	 */
	public function get_post_categories($limit = 0) {
		$this->db->select('id, category_name, category_description, category_slug');
		$this->db->where('is_deleted', 'false');
		if ($limit > 0) $this->db->limit($limit);
		return $this->db->get(self::$table);
	}
}
