<?php defined('BASEPATH') OR exit('No direct script access allowed');



class M_subscribers extends CI_Model {

	/**
	 * Primary key
	 * @var String
	 */
	public static $pk = 'id';

	/**
	 * Table
	 * @var String
	 */
	public static $table = 'subscribers';

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
	}
	
	/**
	 * Save Subscriber
	 * @param String $email
	 * @return Boolean
	 */
	public function save($email) {
		$count = $this->db
			->where('email', $email)
			->count_all_results(self::$table);
		if ($count === 0) {
			return $this->model->insert(self::$table, ['email' => $email]);
		}
		return FALSE;
	}
}
