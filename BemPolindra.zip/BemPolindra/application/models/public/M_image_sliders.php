<?php defined('BASEPATH') OR exit('No direct script access allowed');


class M_image_sliders extends CI_Model {

	/**
	 * Primary key
	 * @var String
	 */
	public static $pk = 'id';

	/**
	 * Table
	 * @var String
	 */
	public static $table = 'image_sliders';

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Get All Image Sliders
	 * @access public
	 * @return Resource
	 */
	public function get_image_sliders($limit = 0) {
		$this->db->select('id, caption, image');
		$this->db->where('is_deleted', 'false');
		if ($limit > 0) $this->db->limit($limit);
		return $this->db->get(self::$table);
	}
}
