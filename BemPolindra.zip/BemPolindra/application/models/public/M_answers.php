<?php defined('BASEPATH') OR exit('No direct script access allowed');


class M_answers extends CI_Model {

	/**
	 * Primary key
	 * @var String
	 */
	public static $pk = 'id';

	/**
	 * Table
	 * @var String
	 */
	public static $table = 'answers';

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Get All Answer By Question ID
	 * @param Int $question_id
	 * @return Resource
	 */
	public function get_answers($question_id = 0) {
		return $this->db
			->select('id, answer')
			->where('question_id', (int) $question_id)
			->where('is_deleted', 'false')
			->get('answers');
	}
}
