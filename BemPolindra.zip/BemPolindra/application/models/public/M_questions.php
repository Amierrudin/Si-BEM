<?php defined('BASEPATH') OR exit('No direct script access allowed');



class M_questions extends CI_Model {

	/**
	 * Primary key
	 * @var String
	 */
	public static $pk = 'id';

	/**
	 * Table
	 * @var String
	 */
	public static $table = 'questions';

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Get Active Question
	 * @return Resource
	 */
	public function get_active_question() {
		return $this->db
			->select('id, question')
			->where('is_active', 'true')
			->where('is_deleted', 'false')
			->limit(1)
			->get(self::$table)
			->row();
	}
}
