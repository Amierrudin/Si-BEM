<?php defined('BASEPATH') OR exit('No direct script access allowed');


class M_pages extends CI_Model {

	/**
	 * Primary key
	 * @var String
	 */
	public static $pk = 'id';

	/**
	 * Table
	 * @var String
	 */
	public static $table = 'posts';

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Search
	 * @param String $keyword
	 * @return Resource
	 */
	public function search($keyword) {
		$this->db->select('id, post_title, post_content, post_slug');
		$this->db->where('post_type', 'page');
		$this->db->where('post_status', 'publish');
		if (!$this->auth->hasLogin()) $this->db->where('post_visibility', 'public');
		$this->db->where('is_deleted', 'false');
		$this->db->group_start();
		$this->db->like('LOWER(post_title)', strtolower($keyword));
		$this->db->or_like('LOWER(post_content)', strtolower($keyword));
		$this->db->group_end();
		$this->db->limit(10);
		return $this->db->get(self::$table);
	}
}
