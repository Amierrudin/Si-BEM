<?php defined('BASEPATH') OR exit('No direct script access allowed');


class M_alumni extends CI_Model {

	/**
	 * Primary key
	 * @var String
	 */
	public static $pk = 'id';

	/**
	 * Table
	 * @var String
	 */
	public static $table = 'students';

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Get Alumni
	 * @param Int $offset
	 * @return Resource
	 */
	public function get_alumni($offset = 0) {
		$this->db->select("
			id
			, identity_number
			, full_name
			, IF(gender = 'M', 'L', 'P') AS gender
			, birth_place
			, LEFT(start_date, 4) AS start_date
			, LEFT(end_date, 4) AS end_date
			, birth_date
			, photo
		");
		$this->db->where('is_deleted', 'false');
		$this->db->where('is_alumni', 'true');
		$this->db->order_by('end_date', 'ASC');
		$this->db->order_by('full_name', 'ASC');
		return $this->db->get(self::$table, 20, $offset);
	}

	/**
	 * Get Total Rows
	 * @return Int
	 */
	public function total_rows() {
		return $this->db
			->where('is_deleted', 'false')
			->where('is_alumni', 'true')
			->count_all_results(self::$table);
	}
}
