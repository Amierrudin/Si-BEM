<?php defined('BASEPATH') OR exit('No direct script access allowed');



class M_quotes extends CI_Model {

	/**
	 * Primary key
	 * @var String
	 */
	public static $pk = 'id';

	/**
	 * Table
	 * @var String
	 */
	public static $table = 'quotes';

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Get All Quotes
	 * @param Int $limit
	 * @return Resource
	 */
	public function get_quotes($limit = 0) {
		$this->db->select('id, quote, quote_by');
		$this->db->where('is_deleted', 'false');
		$this->db->order_by('created_at', 'DESC');
		if ($limit > 0) $this->db->limit($limit);
		return $this->db->get(self::$table);
	}
}
