<?php defined('BASEPATH') OR exit('No direct script access allowed');



class M_students extends CI_Model {

	/**
	 * Primary key
	 * @var String
	 */
	public static $pk = 'id';

	/**
	 * Table
	 * @var String
	 */
	public static $table = 'students';

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * More Students
	 * @param Int
	 * @return Resource
	 */
	public function search_students($academic_year_id, $class_group_id) {
		$this->db->select("
			x1.id
		  , x2.identity_number
		  , x2.full_name
		  , IF(x2.gender = 'M', 'L', 'P') AS gender
		  , COALESCE(x2.birth_place, '') birth_place
		  , x2.birth_date
		  , x2.photo
		");
		$this->db->join('students x2', 'x1.student_id = x2.id', 'LEFT');
		$this->db->where('x1.is_deleted', 'false');
		$this->db->where('x1.academic_year_id', (int) $academic_year_id);
		$this->db->where('x1.class_group_id', (int) $class_group_id);
		$this->db->order_by('x2.full_name', 'ASC');
		return $this->db->get('class_group_settings x1');
	}
}
