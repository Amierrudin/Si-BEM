<?php defined('BASEPATH') OR exit('No direct script access allowed');



class M_links extends CI_Model {

	/**
	 * Primary key
	 * @var String
	 */
	public static $pk = 'id';

	/**
	 * Table
	 * @var String
	 */
	public static $table = 'links';

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Get All Link
	 * @param Int $limit
	 * @return Resource
	 */
	public function get_links($limit = 0) {
		$this->db->select('id, link_title, link_url, link_target');
		$this->db->where('link_type', 'link');
		$this->db->where('is_deleted', 'false');
		if ($limit > 0) $this->db->limit($limit);
		return $this->db->get(self::$table);
	}
}
