<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * CMS Sekolahku | CMS (Content Management System) dan PPDB/PMB Online GRATIS
 * untuk sekolah SD/Sederajat, SMP/Sederajat, SMA/Sederajat, dan Perguruan Tinggi
 * @version    2.3.0
 * @author     Anton Sofyan | https://facebook.com/antonsofyan | 4ntonsofyan@gmail.com | 0857 5988 8922
 * @copyright  (c) 2014-2019
 * @link       http://sekolahku.web.id
 *
 * PERINGATAN :
 * 1. TIDAK DIPERKENANKAN MEMPERJUALBELIKAN APLIKASI INI TANPA SEIZIN DARI PIHAK PENGEMBANG APLIKASI.
 * 2. TIDAK DIPERKENANKAN MENGHAPUS KODE SUMBER APLIKASI.
 * 3. TIDAK MENYERTAKAN LINK KOMERSIL (JASA LAYANAN HOSTING DAN DOMAIN) YANG MENGUNTUNGKAN SEPIHAK.
 */

class M_menus extends CI_Model {

	/**
	 * Primary key
	 * @var String
	 */
	public static $pk = 'id';

	/**
	 * Table
	 * @var String
	 */
	public static $table = 'menus';

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Get All Menus
	 * @return Resource
	 */
	public function get_menus() {
		return $this->db
			->select('id, menu_title, menu_url, menu_type, is_deleted')
			->order_by('menu_parent_id', 'ASC')
			->order_by('menu_position', 'ASC')
			->get(self::$table);
	}

	/**
	 * Fungsi untuk menu recursive
	 * @param Int $menu_parent_id
	 * @return Array
	 */
	public function parent_menus($menu_parent_id = 0) {
		$menus = [];
		$this->db->where('menu_parent_id', $menu_parent_id);
		$this->db->order_by('menu_position', 'ASC');
		$query = $this->db->get(self::$table);
		foreach ($query->result() as $row) {
			$menus[] = [
				'id' => $row->id,
				'menu_title' => $row->menu_title,
				'child' => $this->parent_menus($row->id),
			];
		}
		return $menus;
	}

	/**
	 * Recursive function for save menu position
	 * @return Void
	 */
	public function save_positions($menu_parent_id, $children) {
		$i = 1;
		foreach ($children as $key => $value) {
			$id = $children[$key]['id'];
			$fill_data = [
				'menu_parent_id' => $menu_parent_id,
				'menu_position' => $i
			];
			$this->db->where(self::$pk, $id)->update(self::$table, $fill_data);
			if (isset($children[$key]['children'][0])) {
				$this->save_positions($id, $children[$key]['children']);
			}
			$i++;
		}
	}
}
