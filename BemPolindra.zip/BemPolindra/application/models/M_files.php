<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * CMS Sekolahku | CMS (Content Management System) dan PPDB/PMB Online GRATIS
 * untuk sekolah SD/Sederajat, SMP/Sederajat, SMA/Sederajat, dan Perguruan Tinggi
 * @version    2.3.0
 * @author     Anton Sofyan | https://facebook.com/antonsofyan | 4ntonsofyan@gmail.com | 0857 5988 8922
 * @copyright  (c) 2014-2019
 * @link       http://sekolahku.web.id
 *
 * PERINGATAN :
 * 1. TIDAK DIPERKENANKAN MEMPERJUALBELIKAN APLIKASI INI TANPA SEIZIN DARI PIHAK PENGEMBANG APLIKASI.
 * 2. TIDAK DIPERKENANKAN MENGHAPUS KODE SUMBER APLIKASI.
 * 3. TIDAK MENYERTAKAN LINK KOMERSIL (JASA LAYANAN HOSTING DAN DOMAIN) YANG MENGUNTUNGKAN SEPIHAK.
 */

class M_files extends CI_Model {

	/**
	 * Primary key
	 * @var String
	 */
	public static $pk = 'id';

	/**
	 * Table
	 * @var String
	 */
	public static $table = 'files';

	/**
	 * Class Constructor
	 *
	 * @return Void
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Display a listing of the resource.
	 * @param String $keyword
	 * @param Integer $limit
	 * @param Integer $offset
	 * @return Resource
	 */
	public function get_where($keyword = '', $limit = 10, $offset = 0) {
		$this->db->select('
			x1.id
			, x1.file_title
			, x1.file_name
			, x1.file_ext
			, x1.file_size
			, x2.category_name
			, x1.file_counter
			, x1.file_visibility
			, x1.is_deleted
		');
		$this->db->join('categories x2', 'x1.file_category_id = x2.id',  'LEFT');
		$this->db->where('x2.category_type', 'file');
		if (!empty($keyword)) {
			$this->db->group_start();
			$this->db->like('x1.file_title', $keyword);
			$this->db->or_like('x1.file_name', $keyword);
			$this->db->or_like('x1.file_ext', $keyword);
			$this->db->or_like('x1.file_size', $keyword);
			$this->db->or_like('x2.category_name', $keyword);
			$this->db->or_like('x1.file_visibility', $keyword);
			$this->db->group_end();
		}
		return $this->db->get(self::$table.' x1', $limit, $offset);
	}

	/**
	 * Get total rows of the resource
	 * @param String $keyword
	 * @return Integer
	 */
	public function total_rows($keyword = '') {
		$this->db->join('categories x2', 'x1.file_category_id = x2.id',  'LEFT');
		$this->db->where('x2.category_type', 'file');
		if (!empty($keyword)) {
			$this->db->group_start();
			$this->db->like('x1.file_title', $keyword);
			$this->db->or_like('x1.file_name', $keyword);
			$this->db->or_like('x1.file_ext', $keyword);
			$this->db->or_like('x1.file_size', $keyword);
			$this->db->or_like('x2.category_name', $keyword);
			$this->db->or_like('x1.file_visibility', $keyword);
			$this->db->group_end();
		}
		return $this->db->count_all_results('files x1');
	}
}
