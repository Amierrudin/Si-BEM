SET FOREIGN_KEY_CHECKS=0;

ALTER TABLE `achievements` MODIFY COLUMN `student_id` BIGINT(20) NULL DEFAULT 0;
ALTER TABLE `achievements` CHANGE COLUMN `description` `achievement_description` VARCHAR(255) NOT NULL;
ALTER TABLE `achievements` CHANGE COLUMN `type` `achievement_type` BIGINT(20) NULL DEFAULT 0;
ALTER TABLE `achievements` CHANGE COLUMN `level` `achievement_level` SMALLINT(6) NOT NULL DEFAULT 0;
ALTER TABLE `achievements` CHANGE COLUMN `year` `achievement_year` YEAR NOT NULL;
ALTER TABLE `achievements` CHANGE COLUMN `organizer` `achievement_organizer` VARCHAR(255) NOT NULL;

ALTER TABLE `admission_phases` DROP INDEX `unique_field`;
ALTER TABLE `admission_phases` CHANGE COLUMN `year` `academic_year_id` BIGINT(20) NULL DEFAULT 0 COMMENT 'Tahun Pelajaran';
ALTER TABLE `admission_phases` CHANGE COLUMN `phase` `phase_name` VARCHAR(255) NOT NULL COMMENT 'Gelombang Pendaftaran';
ALTER TABLE `admission_phases` CHANGE COLUMN `start_date` `phase_start_date` date NULL DEFAULT NULL COMMENT 'Tanggal Mulai';
ALTER TABLE `admission_phases` CHANGE COLUMN `end_date` `phase_end_date` date NULL DEFAULT NULL COMMENT 'Tanggal Selesai';
ALTER TABLE `admission_phases` ADD UNIQUE INDEX `unique_field`(`academic_year_id`, `phase_name`) USING BTREE;
ALTER TABLE `admission_phases` ADD INDEX `admission_phases_academic_year_id__idx`(`academic_year_id`) USING BTREE;

ALTER TABLE `admission_quotas` DROP INDEX `unique_field`;
ALTER TABLE `admission_quotas` DROP INDEX `registration_student_id__idx`;
ALTER TABLE `admission_quotas` MODIFY COLUMN `quota` smallint(6) NOT NULL DEFAULT 0 COMMENT 'Kuota Pendaftaran';
ALTER TABLE `admission_quotas` CHANGE COLUMN `year` `academic_year_id` BIGINT(20) NULL DEFAULT 0 COMMENT 'Tahun Pelajaran';
ALTER TABLE `admission_quotas` ADD COLUMN `admission_type_id` BIGINT(20) NULL DEFAULT 0 COMMENT 'Jalur Pendaftaran' AFTER `academic_year_id`;
ALTER TABLE `admission_quotas` ADD UNIQUE INDEX `unique_field`(`academic_year_id`, `admission_type_id`, `major_id`) USING BTREE;
ALTER TABLE `admission_quotas` ADD INDEX `admission_quotas_academic_year_id__idx`(`academic_year_id`) USING BTREE;
ALTER TABLE `admission_quotas` ADD INDEX `admission_quotas_admission_type_id__idx`(`admission_type_id`) USING BTREE;
ALTER TABLE `admission_quotas` ADD INDEX `admission_quotas_major_id__idx`(`major_id`) USING BTREE;

TRUNCATE TABLE `class_group_settings`;
ALTER TABLE `class_group_settings` DROP INDEX `unique_field`;
ALTER TABLE `class_group_settings` DROP INDEX `class_group_settings_student_id__idx`;
ALTER TABLE `class_group_settings` MODIFY COLUMN `academic_year_id` BIGINT(20) NULL DEFAULT 0 COMMENT 'FK dari academic_years';
ALTER TABLE `class_group_settings` MODIFY COLUMN `class_group_id` BIGINT(20) NULL DEFAULT 0 COMMENT 'Kelas, FK dari class_groups';
ALTER TABLE `class_group_settings` ADD COLUMN `employee_id` BIGINT(20) NULL DEFAULT 0 COMMENT 'Wali Kelas, FK dari employees' AFTER `class_group_id`;
ALTER TABLE `class_group_settings` DROP COLUMN `student_id`;
ALTER TABLE `class_group_settings` ADD UNIQUE INDEX `unique_field`(`academic_year_id`, `class_group_id`) USING BTREE;

DROP TABLE IF EXISTS `class_group_students`;
CREATE TABLE IF NOT EXISTS `class_group_students` (
  `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `class_group_setting_id` BIGINT(20) NULL DEFAULT 0,
  `student_id` BIGINT(20) NULL DEFAULT 0,
  `is_class_manager` ENUM('true','false') NOT NULL DEFAULT 'false' COMMENT 'Ketua Kelas ?',
  `created_at` DATETIME NULL,
  `updated_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` DATETIME NULL,
  `restored_at` DATETIME NULL,
  `created_by` BIGINT(20) NULL DEFAULT 0,
  `updated_by` BIGINT(20) NULL DEFAULT 0,
  `deleted_by` BIGINT(20) NULL DEFAULT 0,
  `restored_by` BIGINT(20) NULL DEFAULT 0,
  `is_deleted` ENUM('true','false') DEFAULT 'false',
  UNIQUE KEY `unique_field` (`class_group_setting_id`,`student_id`),
  KEY `class_group_students_class_group_setting_id__idx` (`class_group_setting_id`) USING BTREE,
  KEY `class_group_students_student_id__idx` (`student_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `class_groups` DROP INDEX `unique_field`;
ALTER TABLE `class_groups` CHANGE COLUMN `class` `class_group` VARCHAR(100) NULL DEFAULT NULL;
ALTER TABLE `class_groups` CHANGE COLUMN `sub_class` `sub_class_group` VARCHAR(100) NULL DEFAULT NULL;
ALTER TABLE `class_groups` MODIFY COLUMN `major_id` BIGINT(20) NULL DEFAULT 0 COMMENT 'Program Keahlian';
ALTER TABLE `class_groups` ADD UNIQUE INDEX `unique_field`(`class_group`, `sub_class_group`, `major_id`) USING BTREE;

ALTER TABLE `comments` MODIFY COLUMN `comment_post_id` BIGINT(20) NULL DEFAULT 0 AFTER `id`;
ALTER TABLE `comments` CHANGE COLUMN `comment_ip` `comment_ip_address` VARCHAR(255) NOT NULL;
ALTER TABLE `comments` CHANGE COLUMN `parent_id` `comment_parent_id` VARCHAR(255) NULL DEFAULT NULL;

ALTER TABLE `employees` MODIFY COLUMN `laboratory_skill_id` BIGINT(20) NULL DEFAULT 0 COMMENT 'Keahlian Lab oratorium' AFTER `headmaster_license`;

ALTER TABLE `files` MODIFY COLUMN `file_category_id` BIGINT(20) NULL DEFAULT 0 AFTER `file_type`;
ALTER TABLE `files` MODIFY COLUMN `file_counter` BIGINT(20) NULL DEFAULT 0 AFTER `file_visibility`;

ALTER TABLE `links` CHANGE COLUMN `title` `link_title` VARCHAR(255) NOT NULL AFTER `id`;
ALTER TABLE `links` CHANGE COLUMN `url` `link_url` VARCHAR(255) NULL DEFAULT NULL AFTER `link_title`;
ALTER TABLE `links` CHANGE COLUMN `target` `link_target` enum('_blank','_self','_parent','_top') NULL DEFAULT '_blank' AFTER `link_url`;
ALTER TABLE `links` ADD COLUMN `link_image` VARCHAR(100) NULL DEFAULT NULL AFTER `link_target`;
ALTER TABLE `links` ADD COLUMN `link_type` enum('link','banner') NULL DEFAULT 'link' AFTER `link_image`;
ALTER TABLE `links` DROP INDEX `url`;
ALTER TABLE `links` ADD UNIQUE INDEX `unique_field`(`link_url`, `link_type`) USING BTREE;

ALTER TABLE `majors` DROP INDEX `major`;
ALTER TABLE `majors` CHANGE COLUMN `major` `major_name` VARCHAR(255) NULL DEFAULT NULL COMMENT 'Program Keahlian / Jurusan' AFTER `id`;
ALTER TABLE `majors` CHANGE COLUMN `short_name` `major_short_name` VARCHAR(255) NULL DEFAULT NULL COMMENT 'Nama Singkat' AFTER `major_name`;
ALTER TABLE `majors` ADD COLUMN `is_active` enum('true','false') NULL DEFAULT 'true' AFTER `major_short_name`;
ALTER TABLE `majors` ADD UNIQUE INDEX `major_name`(`major_name`) USING BTREE;

ALTER TABLE `menus` CHANGE COLUMN `parent_id` `menu_parent_id` BIGINT(20) NULL DEFAULT 0;
ALTER TABLE `menus` CHANGE COLUMN `position` `menu_position` BIGINT(20) NULL DEFAULT 0;

ALTER TABLE `modules` DROP COLUMN `is_active`;

ALTER TABLE `options` DROP INDEX `unique_field`;
ALTER TABLE `options` CHANGE COLUMN `option_type` `option_group` VARCHAR(100) NOT NULL AFTER `id`;
ALTER TABLE `options` MODIFY COLUMN `option_name` VARCHAR(255) NULL DEFAULT NULL AFTER `option_group`;
ALTER TABLE `options` MODIFY COLUMN `is_deleted` enum('true','false') NULL DEFAULT 'false' AFTER `restored_by`;
ALTER TABLE `options` ADD UNIQUE INDEX `unique_field`(`option_group`, `option_name`) USING BTREE;
ALTER TABLE `options` ADD INDEX `options_option_group__idx`(`option_group`) USING BTREE;

ALTER TABLE `photos` MODIFY COLUMN `photo_album_id` BIGINT(20) NULL DEFAULT 0 AFTER `id`;

ALTER TABLE `posts` MODIFY COLUMN `post_status` enum('publish','draft') NULL DEFAULT 'draft' AFTER `post_type`;
ALTER TABLE `posts` MODIFY COLUMN `post_comment_status` enum('open','close') NULL DEFAULT 'close' AFTER `post_visibility`;

ALTER TABLE `scholarships` MODIFY COLUMN `student_id` BIGINT(20) NULL DEFAULT 0 AFTER `id`;
ALTER TABLE `scholarships` CHANGE COLUMN `type` `scholarship_type` BIGINT(20) NULL DEFAULT 0 AFTER `student_id`;
ALTER TABLE `scholarships` CHANGE COLUMN `description` `scholarship_description` VARCHAR(255) NOT NULL AFTER `scholarship_type`;
ALTER TABLE `scholarships` CHANGE COLUMN `start_year` `scholarship_start_year` year NOT NULL AFTER `scholarship_description`;
ALTER TABLE `scholarships` CHANGE COLUMN `end_year` `scholarship_end_year` year NOT NULL AFTER `scholarship_start_year`;

ALTER TABLE `subscribers` DROP COLUMN `is_active`;

ALTER TABLE `user_groups` DROP INDEX `group`;
ALTER TABLE `user_groups` CHANGE COLUMN `group` `user_group` VARCHAR(255) NOT NULL AFTER `id`;
ALTER TABLE `user_groups` ADD UNIQUE INDEX `user_group`(`user_group`) USING BTREE;

ALTER TABLE `user_privileges` MODIFY COLUMN `user_group_id` BIGINT(20) NULL DEFAULT 0 AFTER `id`;
ALTER TABLE `user_privileges` MODIFY COLUMN `module_id` BIGINT(20) NULL DEFAULT 0 AFTER `user_group_id`;

ALTER TABLE `users` DROP INDEX `users_profile_id__idx`;
ALTER TABLE `users` MODIFY COLUMN `user_group_id` BIGINT(20) NULL DEFAULT 0 AFTER `user_registered`;
ALTER TABLE `users` CHANGE COLUMN `profile_id` `user_profile_id` BIGINT(20) UNSIGNED NULL DEFAULT NULL COMMENT 'student_id OR employee_id' AFTER `user_type`;
ALTER TABLE `users` CHANGE COLUMN `biography` `user_biography` text NULL AFTER `user_profile_id`;
ALTER TABLE `users` CHANGE COLUMN `forgot_password_key` `user_forgot_password_key` VARCHAR(100) NULL DEFAULT NULL AFTER `user_biography`;
ALTER TABLE `users` CHANGE COLUMN `forgot_password_request_date` `user_forgot_password_request_date` date NULL DEFAULT NULL AFTER `user_forgot_password_key`;
ALTER TABLE `users` CHANGE COLUMN `is_logged_in` `has_login` enum('true','false') NULL DEFAULT 'false' AFTER `user_forgot_password_request_date`;
ALTER TABLE `users` ADD INDEX `users_user_profile_id__idx`(`user_profile_id`) USING BTREE;
ALTER TABLE `users` DROP COLUMN `is_active`;

INSERT INTO options (option_name, option_group) SELECT admission_type, 'admission_types' AS admission_types FROM admission_types;
DROP TABLE `admission_types`;

INSERT INTO links (link_title, link_url, link_target, link_image, link_type) SELECT title, url, target, image, 'banner' AS link_type FROM banners;
DROP TABLE `banners`;

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `category_name` VARCHAR(255) NOT NULL,
  `category_slug` VARCHAR(255) DEFAULT NULL,
  `category_description` VARCHAR(255) DEFAULT NULL,
  `category_type` ENUM('post','file') DEFAULT 'post',
  `created_at` DATETIME NULL,
  `updated_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` DATETIME NULL,
  `restored_at` DATETIME NULL,
  `created_by` BIGINT(20) NULL DEFAULT 0,
  `updated_by` BIGINT(20) NULL DEFAULT 0,
  `deleted_by` BIGINT(20) NULL DEFAULT 0,
  `restored_by` BIGINT(20) NULL DEFAULT 0,
  `is_deleted` ENUM('true','false') DEFAULT 'false',
  UNIQUE KEY `unique_field` (`category_name`,`category_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO categories (id, category_name, category_slug, category_description, category_type)
SELECT id, category, slug, description, 'post' AS category_type FROM post_categories;

INSERT INTO categories (category_name, category_slug, category_description, category_type)
SELECT category, slug, description, 'file' AS category_type FROM file_categories;

UPDATE files x1
LEFT JOIN file_categories x2
    ON x1.file_category_id = x2.id
LEFT JOIN categories x3
   ON LOWER(x2.category) = LOWER(x3.category_name) AND x3.category_type = 'file'
SET x1.file_category_id = x3.id;

DROP TABLE `file_categories`;
DROP TABLE `post_categories`;

UPDATE options SET option_group = 'achievement_levels' WHERE option_group = 'achievement_level';
UPDATE options SET option_group = 'achievement_types' WHERE option_group = 'achievement_type';
UPDATE options SET option_group = 'admission_types' WHERE option_group = 'admission_types';
UPDATE options SET option_group = 'educations' WHERE option_group = 'education';
UPDATE options SET option_group = 'employments' WHERE option_group = 'employment';
UPDATE options SET option_group = 'employment_status' WHERE option_group = 'employment_status';
UPDATE options SET option_group = 'employment_types' WHERE option_group = 'employment_type';
UPDATE options SET option_group = 'institution_lifters' WHERE option_group = 'institution_lifter';
UPDATE options SET option_group = 'laboratory_skills' WHERE option_group = 'laboratory_skill';
UPDATE options SET option_group = 'marriage_status' WHERE option_group = 'marriage_status';
UPDATE options SET option_group = 'monthly_incomes' WHERE option_group = 'monthly_income';
UPDATE options SET option_group = 'ranks' WHERE option_group = 'rank';
UPDATE options SET option_group = 'religions' WHERE option_group = 'religion';
UPDATE options SET option_group = 'residences' WHERE option_group = 'residence';
UPDATE options SET option_group = 'salary_sources' WHERE option_group = 'salary_source';
UPDATE options SET option_group = 'scholarships' WHERE option_group = 'scholarship';
UPDATE options SET option_group = 'school_levels' WHERE option_group = 'school_level';
UPDATE options SET option_group = 'special_needs' WHERE option_group = 'special_need';
UPDATE options SET option_group = 'student_status' WHERE option_group = 'student_status';
UPDATE options SET option_group = 'transportations' WHERE option_group = 'transportation';

SET FOREIGN_KEY_CHECKS=1;
